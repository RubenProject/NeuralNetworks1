import numpy as np
import math
import random
import sys

#sigmoid
def g(x):
    return 1 / (1 + math.exp(-x))


def xor_net(x1, x2, w):
    h1 = 1 * w[0] + x1 * w[1] + x2 * w[2]
    h2 = 1 * w[3] + x1 * w[4] + x2 * w[5]
    h1 = g(h1)
    h2 = g(h2)
    y = 1 * w[6] + h1 * w[7] + h2 * w[8]
    return g(y)


def mse(weights):
    se_00 = (xor_net(0, 0, weights) - 0)
    se_00 = se_00 * se_00
    se_01 = (xor_net(0, 1, weights) - 1)
    se_01 = se_01 * se_01
    se_10 = (xor_net(1, 0, weights) - 1)
    se_10 = se_10 * se_10
    se_11 = (xor_net(1, 1, weights) - 0)
    se_11 = se_11 * se_11
    mean = se_00 + se_01 + se_10 + se_11
    mean = mean / 4
    return(mean)


def grdmse(w):
    e = 10e-3
    gw = [0] * 9
    w0 = mse(w)
    for i in range(0, 9):
        w[i] = w[i] + e
        gw[i] = (mse(w) - w0) / e
        w[i] = w[i] - e
    return gw
    
           
def main(init_w, learn_rate):
    w = init_w
    eta = learn_rate
    epochs = 50000
        
    for i in range(0, epochs):        
        #update w
        gw = grdmse(w)
        for j in range (0, 9):
            w[j] = w[j] - eta * gw[j]
            
        #print mse(w) & error rate for every 500 upgrades of w
        if i%5000 == 0:
            error_nr = 0
            for k in range(0,1000):
                result = xor_net(train_X1[k], train_X2[k],w)
                if result > 0.5:
                    pred_class = 1
                else:
                    pred_class = 0
                if pred_class != train_class[k]:
                    error_nr += 1
            print(f'weights update: {i}th, mse: {mse(w)}, misclassification: {error_nr}') 
    
    #return the prediction accuracy of the final weights
    correct = 0
    for k in range(0,1000):
                result = xor_net(train_X1[k], train_X2[k],w)
                if result > 0.5:
                    pred_class = 1
                else:
                    pred_class = 0
                if pred_class == train_class[k]:
                    correct += 1
    return(correct/1000)
    print(w)


# In[81]:


#generate train set, size = 1000
train_X1 = np.random.randint(2, size=1000)
train_X2 = np.random.randint(2, size=1000)
def xor(x1, x2):
    if x1 != x2:
        pred = 1
    else:
        pred = 0
    return(pred)

train_class = [0]*1000
for i in range(0,1000):
    train_class[i] = xor(train_X1[i], train_X2[i])


# In[19]:


#test with differnt activation function
#f1=sigmoid
#f2=hyperbolic tangent
#f3=linear rectifier

#test with different random initalization
#r1=random draws from unif(-1,1)
#r2=random draws from unif(-4,4)
#r3=random draws from norm(0,1)
#r4=random draws from norm(0,4)

#test with different learning rate(eta)
#e1=0.1
#e2=0.01

#3*4*2 = 24combos


# In[119]:


#c1.sigmoid, r1, e1
f1r1e1_1 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f1r1e1_2 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f1r1e1_3 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f1r1e1_4 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f1r1e1_5 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
np.mean([f1r1e1_1, f1r1e1_2, f1r1e1_3, f1r1e1_4, f1r1e1_5])


# In[120]:


#c2.sigmoid, r1, e2
f1r1e2_1 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f1r1e2_2 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f1r1e2_3 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f1r1e2_4 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f1r1e2_5 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
np.mean([f1r1e2_1, f1r1e2_2, f1r1e2_3, f1r1e2_4, f1r1e2_5])


# In[121]:


#c3.sigmoid, r2, e1
f1r2e1_1 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f1r2e1_2 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f1r2e1_3 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f1r2e1_4 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f1r2e1_5 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
np.mean([f1r2e1_1, f1r2e1_2, f1r2e1_3, f1r2e1_4, f1r2e1_5])


# In[122]:


#c4.sigmoid, r2, e2
f1r2e2_1 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f1r2e2_2 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f1r2e2_3 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f1r2e2_4 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f1r2e2_5 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
np.mean([f1r2e2_1, f1r2e2_2, f1r2e2_3, f1r2e2_4, f1r2e2_5])


# In[123]:


#c5.sigmoid, r3, e1
f1r3e1_1 = main(np.random.normal(0,1,9), 0.1)
f1r3e1_2 = main(np.random.normal(0,1,9), 0.1)
f1r3e1_3 = main(np.random.normal(0,1,9), 0.1)
f1r3e1_4 = main(np.random.normal(0,1,9), 0.1)
f1r3e1_5 = main(np.random.normal(0,1,9), 0.1)
np.mean([f1r3e1_1, f1r3e1_2, f1r3e1_3, f1r3e1_4, f1r3e1_5])


# In[124]:


#c6.sigmoid, r3, e2
f1r3e2_1 = main(np.random.normal(0,1,9), 0.01)
f1r3e2_2 = main(np.random.normal(0,1,9), 0.01)
f1r3e2_3 = main(np.random.normal(0,1,9), 0.01)
f1r3e2_4 = main(np.random.normal(0,1,9), 0.01)
f1r3e2_5 = main(np.random.normal(0,1,9), 0.01)
np.mean([f1r3e2_1, f1r3e2_2, f1r3e2_3, f1r3e2_4, f1r3e2_5])


# In[ ]:


#c7.sigmoid, r4, e1
f1r4e1_1 = main(np.random.normal(0,4,9), 0.1)
f1r4e1_2 = main(np.random.normal(0,4,9), 0.1)
f1r4e1_3 = main(np.random.normal(0,4,9), 0.1)
f1r4e1_4 = main(np.random.normal(0,4,9), 0.1)
f1r4e1_5 = main(np.random.normal(0,4,9), 0.1)
np.mean([f1r4e1_1, f1r4e1_2, f1r4e1_3, f1r4e1_4, f1r4e1_5])


# In[ ]:


#c8.sigmoid, r4, e2
f1r4e2_1 = main(np.random.normal(0,4,9), 0.01)
f1r4e2_2 = main(np.random.normal(0,4,9), 0.01)
f1r4e2_3 = main(np.random.normal(0,4,9), 0.01)
f1r4e2_4 = main(np.random.normal(0,4,9), 0.01)
f1r4e2_5 = main(np.random.normal(0,4,9), 0.01)
np.mean([f1r4e2_1, f1r4e2_2, f1r4e2_3, f1r4e2_4, f1r4e2_5])


# In[125]:


#hyperbolic tangent
g = np.tanh


# In[126]:


#c9.hyperbolic tangent, r1, e1
f2r1e1_1 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f2r1e1_2 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f2r1e1_3 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f2r1e1_4 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f2r1e1_5 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
np.mean([f2r1e1_1, f2r1e1_2, f2r1e1_3, f2r1e1_4, f2r1e1_5])


# In[127]:


#c10.hyperbolic tangent, r1, e2
f2r1e2_1 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f2r1e2_2 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f2r1e2_3 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f2r1e2_4 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f2r1e2_5 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
np.mean([f2r1e2_1, f2r1e2_2, f2r1e2_3, f2r1e2_4, f2r1e2_5])


# In[128]:


#c11.hyperbolic tangent, r2, e1
f2r2e1_1 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f2r2e1_2 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f2r2e1_3 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f2r2e1_4 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f2r2e1_5 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
np.mean([f2r2e1_1, f2r2e1_2, f2r2e1_3, f2r2e1_4, f2r2e1_5])


# In[129]:


#c12.hyperbolic tangent, r2, e2
f2r2e2_1 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f2r2e2_2 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f2r2e2_3 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f2r2e2_4 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f2r2e2_5 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
np.mean([f2r2e2_1, f2r2e2_2, f2r2e2_3, f2r2e2_4, f2r2e2_5])


# In[130]:


#c13.hyperbolic tangent, r3, e1
f2r3e1_1 = main(np.random.normal(0,1,9), 0.1)
f2r3e1_2 = main(np.random.normal(0,1,9), 0.1)
f2r3e1_3 = main(np.random.normal(0,1,9), 0.1)
f2r3e1_4 = main(np.random.normal(0,1,9), 0.1)
f2r3e1_5 = main(np.random.normal(0,1,9), 0.1)
np.mean([f2r3e1_1, f2r3e1_2, f2r3e1_3, f2r3e1_4, f2r3e1_5])


# In[131]:


#c14.hyperbolic tangent, r3, e2
f2r3e2_1 = main(np.random.normal(0,1,9), 0.01)
f2r3e2_2 = main(np.random.normal(0,1,9), 0.01)
f2r3e2_3 = main(np.random.normal(0,1,9), 0.01)
f2r3e2_4 = main(np.random.normal(0,1,9), 0.01)
f2r3e2_5 = main(np.random.normal(0,1,9), 0.01)
np.mean([f2r3e2_1, f2r3e2_2, f2r3e2_3, f2r3e2_4, f2r3e2_5])


# In[132]:


#c15.hyperbolic tangent, r4, e1
f2r4e1_1 = main(np.random.normal(0,4,9), 0.1)
f2r4e1_2 = main(np.random.normal(0,4,9), 0.1)
f2r4e1_3 = main(np.random.normal(0,4,9), 0.1)
f2r4e1_4 = main(np.random.normal(0,4,9), 0.1)
f2r4e1_5 = main(np.random.normal(0,4,9), 0.1)
np.mean([f2r4e1_1, f2r4e1_2, f2r4e1_3, f2r4e1_4, f2r4e1_5])


# In[133]:


#c16.hyperbolic tangent, r4, e2
f2r4e2_1 = main(np.random.normal(0,4,9), 0.01)
f2r4e2_2 = main(np.random.normal(0,4,9), 0.01)
f2r4e2_3 = main(np.random.normal(0,4,9), 0.01)
f2r4e2_4 = main(np.random.normal(0,4,9), 0.01)
f2r4e2_5 = main(np.random.normal(0,4,9), 0.01)
np.mean([f2r4e2_1, f2r4e2_2, f2r4e2_3, f2r4e2_4, f2r4e2_5])


# In[148]:


#linear rectifier
def g(x):
    max(0,x)


# In[149]:


#c17.linear rectifier, r1, e1
f3r1e1_1 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f3r1e1_2 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f3r1e1_3 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f3r1e1_4 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f3r1e1_5 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
np.mean([f3r1e1_1, f3r1e1_2, f3r1e1_3, f3r1e1_4, f3r1e1_5])


# In[138]:


#c18.linear rectifier, r1, e2
f3r1e2_1 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f3r1e2_2 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f3r1e2_3 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f3r1e2_4 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f3r1e2_5 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
np.mean([f3r1e2_1, f3r1e2_2, f3r1e2_3, f3r1e2_4, f3r1e2_5])


# In[139]:


#c19.linear rectifier, r2, e1
f3r2e1_1 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f3r2e1_2 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f3r2e1_3 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f3r2e1_4 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f3r2e1_5 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
np.mean([f3r2e1_1, f3r2e1_2, f3r2e1_3, f3r2e1_4, f3r2e1_5])


# In[140]:


#c20.linear rectifier, r2, e2
f3r2e2_1 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f3r2e2_2 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f3r2e2_3 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f3r2e2_4 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f3r2e2_5 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
np.mean([f3r2e2_1, f3r2e2_2, f3r2e2_3, f3r2e2_4, f3r2e2_5])


# In[141]:


#c21.linear rectifier, r3, e1
f3r3e1_1 = main(np.random.normal(0,1,9), 0.1)
f3r3e1_2 = main(np.random.normal(0,1,9), 0.1)
f3r3e1_3 = main(np.random.normal(0,1,9), 0.1)
f3r3e1_4 = main(np.random.normal(0,1,9), 0.1)
f3r3e1_5 = main(np.random.normal(0,1,9), 0.1)
np.mean([f3r3e1_1, f3r3e1_2, f3r3e1_3, f3r3e1_4, f3r3e1_5])


# In[142]:


#c22.linear rectifier, r3, e2
f3r3e2_1 = main(np.random.normal(0,1,9), 0.01)
f3r3e2_2 = main(np.random.normal(0,1,9), 0.01)
f3r3e2_3 = main(np.random.normal(0,1,9), 0.01)
f3r3e2_4 = main(np.random.normal(0,1,9), 0.01)
f3r3e2_5 = main(np.random.normal(0,1,9), 0.01)
np.mean([f3r3e2_1, f3r3e2_2, f3r3e2_3, f3r3e2_4, f3r3e2_5])


# In[143]:


#c23.linear rectifier, r4, e1
f3r4e1_1 = main(np.random.normal(0,4,9), 0.1)
f3r4e1_2 = main(np.random.normal(0,4,9), 0.1)
f3r4e1_3 = main(np.random.normal(0,4,9), 0.1)
f3r4e1_4 = main(np.random.normal(0,4,9), 0.1)
f3r4e1_5 = main(np.random.normal(0,4,9), 0.1)
np.mean([f3r4e1_1, f3r4e1_2, f3r4e1_3, f3r4e1_4, f3r4e1_5])


# In[144]:


#c24.linear rectifier, r4, e2
f3r4e2_1 = main(np.random.normal(0,4,9), 0.01)
f3r4e2_2 = main(np.random.normal(0,4,9), 0.01)
f3r4e2_3 = main(np.random.normal(0,4,9), 0.01)
f3r4e2_4 = main(np.random.normal(0,4,9), 0.01)
f3r4e2_5 = main(np.random.normal(0,4,9), 0.01)
np.mean([f3r4e2_1, f3r4e2_2, f3r4e2_3, f3r4e2_4, f3r4e2_5])


import numpy as np
import math
import random
import sys

#sigmoid
def g(x):
    return 1 / (1 + math.exp(-x))


def xor_net(x1, x2, w):
    h1 = 1 * w[0] + x1 * w[1] + x2 * w[2]
    h2 = 1 * w[3] + x1 * w[4] + x2 * w[5]
    h1 = g(h1)
    h2 = g(h2)
    y = 1 * w[6] + h1 * w[7] + h2 * w[8]
    return g(y)


def mse(weights):
    se_00 = (xor_net(0, 0, weights) - 0)
    se_00 = se_00 * se_00
    se_01 = (xor_net(0, 1, weights) - 1)
    se_01 = se_01 * se_01
    se_10 = (xor_net(1, 0, weights) - 1)
    se_10 = se_10 * se_10
    se_11 = (xor_net(1, 1, weights) - 0)
    se_11 = se_11 * se_11
    mean = se_00 + se_01 + se_10 + se_11
    mean = mean / 4
    return(mean)


def grdmse(w):
    e = 10e-3
    gw = [0] * 9
    w0 = mse(w)
    for i in range(0, 9):
        w[i] = w[i] + e
        gw[i] = (mse(w) - w0) / e
        w[i] = w[i] - e
    return gw
    
           
def main(init_w, learn_rate):
    w = init_w
    eta = learn_rate
    epochs = 50000
        
    for i in range(0, epochs):        
        #update w
        gw = grdmse(w)
        for j in range (0, 9):
            w[j] = w[j] - eta * gw[j]
            
        #print mse(w) & error rate for every 500 upgrades of w
        if i%5000 == 0:
            error_nr = 0
            for k in range(0,1000):
                result = xor_net(train_X1[k], train_X2[k],w)
                if result > 0.5:
                    pred_class = 1
                else:
                    pred_class = 0
                if pred_class != train_class[k]:
                    error_nr += 1
            print(f'weights update: {i}th, mse: {mse(w)}, misclassification: {error_nr}') 
    
    #return the prediction accuracy of the final weights
    correct = 0
    for k in range(0,1000):
                result = xor_net(train_X1[k], train_X2[k],w)
                if result > 0.5:
                    pred_class = 1
                else:
                    pred_class = 0
                if pred_class == train_class[k]:
                    correct += 1
    return(correct/1000)
    print(w)


# In[81]:


#generate train set, size = 1000
train_X1 = np.random.randint(2, size=1000)
train_X2 = np.random.randint(2, size=1000)
def xor(x1, x2):
    if x1 != x2:
        pred = 1
    else:
        pred = 0
    return(pred)

train_class = [0]*1000
for i in range(0,1000):
    train_class[i] = xor(train_X1[i], train_X2[i])


# In[19]:


#test with differnt activation function
#f1=sigmoid
#f2=hyperbolic tangent
#f3=linear rectifier

#test with different random initalization
#r1=random draws from unif(-1,1)
#r2=random draws from unif(-4,4)
#r3=random draws from norm(0,1)
#r4=random draws from norm(0,4)

#test with different learning rate(eta)
#e1=0.1
#e2=0.01

#3*4*2 = 24combos


# In[119]:


#c1.sigmoid, r1, e1
f1r1e1_1 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f1r1e1_2 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f1r1e1_3 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f1r1e1_4 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f1r1e1_5 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
np.mean([f1r1e1_1, f1r1e1_2, f1r1e1_3, f1r1e1_4, f1r1e1_5])


# In[120]:


#c2.sigmoid, r1, e2
f1r1e2_1 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f1r1e2_2 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f1r1e2_3 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f1r1e2_4 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f1r1e2_5 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
np.mean([f1r1e2_1, f1r1e2_2, f1r1e2_3, f1r1e2_4, f1r1e2_5])


# In[121]:


#c3.sigmoid, r2, e1
f1r2e1_1 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f1r2e1_2 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f1r2e1_3 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f1r2e1_4 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f1r2e1_5 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
np.mean([f1r2e1_1, f1r2e1_2, f1r2e1_3, f1r2e1_4, f1r2e1_5])


# In[122]:


#c4.sigmoid, r2, e2
f1r2e2_1 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f1r2e2_2 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f1r2e2_3 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f1r2e2_4 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f1r2e2_5 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
np.mean([f1r2e2_1, f1r2e2_2, f1r2e2_3, f1r2e2_4, f1r2e2_5])


# In[123]:


#c5.sigmoid, r3, e1
f1r3e1_1 = main(np.random.normal(0,1,9), 0.1)
f1r3e1_2 = main(np.random.normal(0,1,9), 0.1)
f1r3e1_3 = main(np.random.normal(0,1,9), 0.1)
f1r3e1_4 = main(np.random.normal(0,1,9), 0.1)
f1r3e1_5 = main(np.random.normal(0,1,9), 0.1)
np.mean([f1r3e1_1, f1r3e1_2, f1r3e1_3, f1r3e1_4, f1r3e1_5])


# In[124]:


#c6.sigmoid, r3, e2
f1r3e2_1 = main(np.random.normal(0,1,9), 0.01)
f1r3e2_2 = main(np.random.normal(0,1,9), 0.01)
f1r3e2_3 = main(np.random.normal(0,1,9), 0.01)
f1r3e2_4 = main(np.random.normal(0,1,9), 0.01)
f1r3e2_5 = main(np.random.normal(0,1,9), 0.01)
np.mean([f1r3e2_1, f1r3e2_2, f1r3e2_3, f1r3e2_4, f1r3e2_5])


# In[ ]:


#c7.sigmoid, r4, e1
f1r4e1_1 = main(np.random.normal(0,4,9), 0.1)
f1r4e1_2 = main(np.random.normal(0,4,9), 0.1)
f1r4e1_3 = main(np.random.normal(0,4,9), 0.1)
f1r4e1_4 = main(np.random.normal(0,4,9), 0.1)
f1r4e1_5 = main(np.random.normal(0,4,9), 0.1)
np.mean([f1r4e1_1, f1r4e1_2, f1r4e1_3, f1r4e1_4, f1r4e1_5])


# In[ ]:


#c8.sigmoid, r4, e2
f1r4e2_1 = main(np.random.normal(0,4,9), 0.01)
f1r4e2_2 = main(np.random.normal(0,4,9), 0.01)
f1r4e2_3 = main(np.random.normal(0,4,9), 0.01)
f1r4e2_4 = main(np.random.normal(0,4,9), 0.01)
f1r4e2_5 = main(np.random.normal(0,4,9), 0.01)
np.mean([f1r4e2_1, f1r4e2_2, f1r4e2_3, f1r4e2_4, f1r4e2_5])


# In[125]:


#hyperbolic tangent
g = np.tanh


# In[126]:


#c9.hyperbolic tangent, r1, e1
f2r1e1_1 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f2r1e1_2 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f2r1e1_3 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f2r1e1_4 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f2r1e1_5 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
np.mean([f2r1e1_1, f2r1e1_2, f2r1e1_3, f2r1e1_4, f2r1e1_5])


# In[127]:


#c10.hyperbolic tangent, r1, e2
f2r1e2_1 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f2r1e2_2 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f2r1e2_3 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f2r1e2_4 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f2r1e2_5 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
np.mean([f2r1e2_1, f2r1e2_2, f2r1e2_3, f2r1e2_4, f2r1e2_5])


# In[128]:


#c11.hyperbolic tangent, r2, e1
f2r2e1_1 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f2r2e1_2 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f2r2e1_3 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f2r2e1_4 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f2r2e1_5 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
np.mean([f2r2e1_1, f2r2e1_2, f2r2e1_3, f2r2e1_4, f2r2e1_5])


# In[129]:


#c12.hyperbolic tangent, r2, e2
f2r2e2_1 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f2r2e2_2 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f2r2e2_3 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f2r2e2_4 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f2r2e2_5 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
np.mean([f2r2e2_1, f2r2e2_2, f2r2e2_3, f2r2e2_4, f2r2e2_5])


# In[130]:


#c13.hyperbolic tangent, r3, e1
f2r3e1_1 = main(np.random.normal(0,1,9), 0.1)
f2r3e1_2 = main(np.random.normal(0,1,9), 0.1)
f2r3e1_3 = main(np.random.normal(0,1,9), 0.1)
f2r3e1_4 = main(np.random.normal(0,1,9), 0.1)
f2r3e1_5 = main(np.random.normal(0,1,9), 0.1)
np.mean([f2r3e1_1, f2r3e1_2, f2r3e1_3, f2r3e1_4, f2r3e1_5])


# In[131]:


#c14.hyperbolic tangent, r3, e2
f2r3e2_1 = main(np.random.normal(0,1,9), 0.01)
f2r3e2_2 = main(np.random.normal(0,1,9), 0.01)
f2r3e2_3 = main(np.random.normal(0,1,9), 0.01)
f2r3e2_4 = main(np.random.normal(0,1,9), 0.01)
f2r3e2_5 = main(np.random.normal(0,1,9), 0.01)
np.mean([f2r3e2_1, f2r3e2_2, f2r3e2_3, f2r3e2_4, f2r3e2_5])


# In[132]:


#c15.hyperbolic tangent, r4, e1
f2r4e1_1 = main(np.random.normal(0,4,9), 0.1)
f2r4e1_2 = main(np.random.normal(0,4,9), 0.1)
f2r4e1_3 = main(np.random.normal(0,4,9), 0.1)
f2r4e1_4 = main(np.random.normal(0,4,9), 0.1)
f2r4e1_5 = main(np.random.normal(0,4,9), 0.1)
np.mean([f2r4e1_1, f2r4e1_2, f2r4e1_3, f2r4e1_4, f2r4e1_5])


# In[133]:


#c16.hyperbolic tangent, r4, e2
f2r4e2_1 = main(np.random.normal(0,4,9), 0.01)
f2r4e2_2 = main(np.random.normal(0,4,9), 0.01)
f2r4e2_3 = main(np.random.normal(0,4,9), 0.01)
f2r4e2_4 = main(np.random.normal(0,4,9), 0.01)
f2r4e2_5 = main(np.random.normal(0,4,9), 0.01)
np.mean([f2r4e2_1, f2r4e2_2, f2r4e2_3, f2r4e2_4, f2r4e2_5])


# In[148]:


#linear rectifier
def g(x):
    max(0,x)


# In[149]:


#c17.linear rectifier, r1, e1
f3r1e1_1 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f3r1e1_2 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f3r1e1_3 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f3r1e1_4 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
f3r1e1_5 = main([random.uniform(-1,1) for _ in range(9)], 0.1)
np.mean([f3r1e1_1, f3r1e1_2, f3r1e1_3, f3r1e1_4, f3r1e1_5])


# In[138]:


#c18.linear rectifier, r1, e2
f3r1e2_1 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f3r1e2_2 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f3r1e2_3 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f3r1e2_4 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
f3r1e2_5 = main([random.uniform(-1,1) for _ in range(9)], 0.01)
np.mean([f3r1e2_1, f3r1e2_2, f3r1e2_3, f3r1e2_4, f3r1e2_5])


# In[139]:


#c19.linear rectifier, r2, e1
f3r2e1_1 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f3r2e1_2 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f3r2e1_3 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f3r2e1_4 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
f3r2e1_5 = main([random.uniform(-4,4) for _ in range(9)], 0.1)
np.mean([f3r2e1_1, f3r2e1_2, f3r2e1_3, f3r2e1_4, f3r2e1_5])


# In[140]:


#c20.linear rectifier, r2, e2
f3r2e2_1 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f3r2e2_2 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f3r2e2_3 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f3r2e2_4 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
f3r2e2_5 = main([random.uniform(-4,4) for _ in range(9)], 0.01)
np.mean([f3r2e2_1, f3r2e2_2, f3r2e2_3, f3r2e2_4, f3r2e2_5])


# In[141]:


#c21.linear rectifier, r3, e1
f3r3e1_1 = main(np.random.normal(0,1,9), 0.1)
f3r3e1_2 = main(np.random.normal(0,1,9), 0.1)
f3r3e1_3 = main(np.random.normal(0,1,9), 0.1)
f3r3e1_4 = main(np.random.normal(0,1,9), 0.1)
f3r3e1_5 = main(np.random.normal(0,1,9), 0.1)
np.mean([f3r3e1_1, f3r3e1_2, f3r3e1_3, f3r3e1_4, f3r3e1_5])


# In[142]:


#c22.linear rectifier, r3, e2
f3r3e2_1 = main(np.random.normal(0,1,9), 0.01)
f3r3e2_2 = main(np.random.normal(0,1,9), 0.01)
f3r3e2_3 = main(np.random.normal(0,1,9), 0.01)
f3r3e2_4 = main(np.random.normal(0,1,9), 0.01)
f3r3e2_5 = main(np.random.normal(0,1,9), 0.01)
np.mean([f3r3e2_1, f3r3e2_2, f3r3e2_3, f3r3e2_4, f3r3e2_5])


# In[143]:


#c23.linear rectifier, r4, e1
f3r4e1_1 = main(np.random.normal(0,4,9), 0.1)
f3r4e1_2 = main(np.random.normal(0,4,9), 0.1)
f3r4e1_3 = main(np.random.normal(0,4,9), 0.1)
f3r4e1_4 = main(np.random.normal(0,4,9), 0.1)
f3r4e1_5 = main(np.random.normal(0,4,9), 0.1)
np.mean([f3r4e1_1, f3r4e1_2, f3r4e1_3, f3r4e1_4, f3r4e1_5])


# In[144]:


#c24.linear rectifier, r4, e2
f3r4e2_1 = main(np.random.normal(0,4,9), 0.01)
f3r4e2_2 = main(np.random.normal(0,4,9), 0.01)
f3r4e2_3 = main(np.random.normal(0,4,9), 0.01)
f3r4e2_4 = main(np.random.normal(0,4,9), 0.01)
f3r4e2_5 = main(np.random.normal(0,4,9), 0.01)
np.mean([f3r4e2_1, f3r4e2_2, f3r4e2_3, f3r4e2_4, f3r4e2_5])

